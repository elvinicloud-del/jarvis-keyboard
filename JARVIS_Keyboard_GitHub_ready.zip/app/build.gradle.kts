plugins {
    id("com.android.application")
}

android {
    namespace = "com.jarvis.keyboard"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jarvis.keyboard"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "0.1"
    }
}
